/** Automatically generated file. DO NOT MODIFY */
package se.ludvig.hourly;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}